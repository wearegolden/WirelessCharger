#include "variable.h"

//adc
Uint16 adc1_cnt = 0;

//dac
Uint16 Vdac;

//epwm

Uint16 epwm1_cnt = 0, epwm2_cnt = 0, EPWM1_TBPRD = 0;
Uint16 PWM_EN = 0, PWM_ENABLE_CNT = 0;

//gpio

//timer

//controller
float32 Vtx_duty = 0., IL = 0.;


void Init_Var(void){

	EPWM1_TBPRD = 180.e6/300.e3/2;
	PWM_EN = 0;
	PWM_ENABLE_CNT = 0;
	Vtx_duty = 0.5;
	IL = 0.;
	Vdac = 0.;

}

