#include "timer.h"

__interrupt void cpu_timer0_isr(void){
	CpuTimer0.InterruptCount++;
	GpioDataRegs.GPATOGGLE.bit.GPIO31 = 1;		//LED toggle
	GpioDataRegs.GPBTOGGLE.bit.GPIO34 = 1;		//LED toggle
	DacaRegs.DACVALS.all = (Uint16)(1241.21 * Vdac); // 4096 / 3.3 * Vdac = DACVALS
	Vdac ++;
	if(Vdac >= 3) Vdac = 0;
	PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}
