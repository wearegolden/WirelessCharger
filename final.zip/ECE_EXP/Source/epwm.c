#include "epwm.h"

__interrupt void epwm1_isr(void)
{
	epwm1_cnt ++;
	IL = (float)((AdcaResultRegs.ADCRESULT0 - 2700) * 0.0043549f); // (adc value - voltage offset adc value) * 3.3 / 4096 / 0.185mV
	if(Vtx_duty > 0.5) Vtx_duty = 0.5;
	else if(Vtx_duty < 0.) Vtx_duty = 0.;
	EPwm1Regs.CMPA.bit.CMPA = (Uint16) (Vtx_duty*EPWM1_TBPRD); //apply duty
	EPwm2Regs.CMPA.bit.CMPA = (Uint16) (Vtx_duty*EPWM1_TBPRD); //apply duty
    EPwm1Regs.ETCLR.bit.INT = 1;
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
}

__interrupt void epwm2_isr(void)
{
	epwm2_cnt ++;
	EPwm2Regs.ETCLR.bit.INT = 1;
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
}

void ConfigureEPWM1(void)
{

	EALLOW;

	EPwm1Regs.ETSEL.bit.SOCAEN = 1;
	EPwm1Regs.ETSEL.bit.SOCASEL = 1;
	EPwm1Regs.ETPS.bit.SOCAPRD = 1;

	EPwm1Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;
	EPwm1Regs.TBCTL.bit.CLKDIV = TB_DIV1;
	EPwm1Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN;
	EPwm1Regs.TBCTL.bit.SYNCOSEL = TB_CTR_ZERO;
	EPwm1Regs.TBCTL.bit.PHSEN = TB_DISABLE;
	EPwm1Regs.TBCTL.bit.PRDLD = TB_SHADOW;

	EPwm1Regs.TBPRD = EPWM1_TBPRD;
	EPwm1Regs.TBPHS.bit.TBPHS = 0x0000;
	EPwm1Regs.TBCTR = 0x0000;

	EPwm1Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
	EPwm1Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
	EPwm1Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;
	EPwm1Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;

	EPwm1Regs.CMPA.bit.CMPA = (Uint16)(EPWM1_TBPRD);

	EPwm1Regs.AQCTLA.bit.CAU = AQ_SET;
	EPwm1Regs.AQCTLA.bit.CAD = AQ_CLEAR;
	EPwm1Regs.AQCTLB.bit.CAU = AQ_SET;
	EPwm1Regs.AQCTLB.bit.CAD = AQ_CLEAR;

	EPwm1Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;
	EPwm1Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;
	EPwm1Regs.DBCTL.bit.IN_MODE = DBA_ALL;
	EPwm1Regs.DBRED.bit.DBRED = 10;
	EPwm1Regs.DBFED.bit.DBFED = 10;

	EPwm1Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;
	EPwm1Regs.ETSEL.bit.INTEN = 1;
	EPwm1Regs.ETPS.bit.INTPRD = ET_1ST;
	EDIS;

}


void ConfigureEPWM2(void)
{
	EALLOW;

	//
	// Setup TBCLK
	//
	EPwm2Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;
	EPwm2Regs.TBCTL.bit.CLKDIV = TB_DIV1;
	EPwm2Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN;
	EPwm2Regs.TBCTL.bit.PHSEN = TB_ENABLE;
	EPwm2Regs.TBCTL.bit.SYNCOSEL = TB_SYNC_IN;
	EPwm2Regs.TBCTL.bit.PRDLD = TB_SHADOW;

	EPwm2Regs.TBPRD = EPWM1_TBPRD;
	EPwm2Regs.TBPHS.bit.TBPHS = EPWM1_TBPRD;
	EPwm2Regs.TBCTR = 0x0000;

	EPwm2Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
	EPwm2Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
	EPwm2Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;
	EPwm2Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;
	EPwm2Regs.CMPA.bit.CMPA = (Uint16)(EPWM1_TBPRD); //	200E6/100kHz/2

	EPwm2Regs.AQCTLA.bit.CAU = AQ_SET;
	EPwm2Regs.AQCTLA.bit.CAD = AQ_CLEAR;

	EPwm2Regs.AQCTLB.bit.CAU = AQ_SET;
	EPwm2Regs.AQCTLB.bit.CAD = AQ_CLEAR;

	EPwm2Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;
	EPwm2Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;
	EPwm2Regs.DBCTL.bit.IN_MODE = DBA_ALL;
	EPwm2Regs.DBRED.bit.DBRED = 10;
	EPwm2Regs.DBFED.bit.DBFED = 10;

	EPwm2Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;
	EPwm2Regs.ETSEL.bit.INTEN = 1;
	EPwm2Regs.ETPS.bit.INTPRD = ET_1ST;

	EDIS;
}
