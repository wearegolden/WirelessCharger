#include "Project.h"

void main(void)
{

    InitSysCtrl();
    InitGpio();
    InitEPwm1Gpio();
    InitEPwm2Gpio();
    ConfigureLED();

    DINT;

    InitPieCtrl();

    IER = 0x0000;
    IFR = 0x0000;

    InitPieVectTable();

    //Interrupt re-mapping to ISR functions
    EALLOW;
    	PieVectTable.TIMER0_INT = &cpu_timer0_isr;
    	PieVectTable.EPWM1_INT = &epwm1_isr;
    	PieVectTable.EPWM2_INT = &epwm2_isr;
    EDIS;

	Init_Var();									//Initialization variables

    InitCpuTimers();							//Initialization CPU timer
    ConfigCpuTimer(&CpuTimer0, 200, 1000000);	//CPU timer, 180MHz, 1e+6 us period
	CpuTimer0Regs.TCR.all = 0x4000; 			//use write-only instructions to write to the entire register

	ConfigureDAC();
	ConfigureEPWM1();
	ConfigureEPWM2();
	ConfigureADC();

	IER |= M_INT1;
	IER |= M_INT3;

	PieCtrlRegs.PIEIER1.bit.INTx7 = 1;	// PIE1.7 - TIMER 0
    PieCtrlRegs.PIEIER3.bit.INTx1 = 1;	// PIE3.1 - EPWM 1
    PieCtrlRegs.PIEIER3.bit.INTx2 = 1;	// PIE3.2 - EPWM 2

    EINT;	//Enable Interrupt
    ERTM;	//

    for(;;)
    {
    	if(PWM_EN == 1){
    		if(PWM_ENABLE_CNT == 0){
				EPwm1Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN;
				EPwm2Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN;
    		}
    	}
		else{
			Vtx_duty = 0.;
			EPwm1Regs.CMPA.bit.CMPA = (Uint16) (EPWM1_TBPRD);
			EPwm2Regs.CMPA.bit.CMPA = (Uint16) (EPWM1_TBPRD);
			EPwm1Regs.TBCTL.bit.CTRMODE = TB_FREEZE;
			EPwm2Regs.TBCTL.bit.CTRMODE = TB_FREEZE;
			PWM_ENABLE_CNT = 0;
		}


    }
}
