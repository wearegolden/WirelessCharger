#include "dac.h"

void ConfigureDAC(void)
{
    EALLOW;

    DacaRegs.DACCTL.bit.DACREFSEL = 1;  // reference = VREFHI
    DacaRegs.DACCTL.bit.LOADMODE = 0;
    DacaRegs.DACOUTEN.bit.DACOUTEN = 1;
    DacaRegs.DACVALS.all = 0;
    DELAY_US(10); // Delay for buffered DAC to power up

    EDIS;
}
