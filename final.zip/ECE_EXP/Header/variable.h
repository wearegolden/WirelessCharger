/*
 * variable.h
 *
 *  Created on: 2019. 4. 16.
 *      Author: PEETS
 */

#ifndef HEADER_VARIABLE_H_
#define HEADER_VARIABLE_H_

#include "Project.h"

//adc
extern Uint16 adc1_cnt;

//dac
extern Uint16 Vdac;

//epwm
extern Uint16 epwm1_cnt, epwm2_cnt, EPWM1_TBPRD;
extern Uint16 PWM_EN, PWM_ENABLE_CNT;

//gpio

//timer

//controller
extern float32 Vtx_duty, IL;

extern void Init_Var(void);

#endif /* HEADER_VARIABLE_H_ */
