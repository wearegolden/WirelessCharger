/*
 * timer.h
 *
 *  Created on: 2019. 4. 16.
 *      Author: PEETS
 */

#ifndef HEADER_TIMER_H_
#define HEADER_TIMER_H_

#include "Project.h"

extern interrupt void cpu_timer0_isr(void);


#endif /* HEADER_TIMER_H_ */
