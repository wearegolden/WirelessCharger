/*
 * Project.h
 *
 *  Created on: 2019. 4. 16.
 *      Author: PEETS
 */

#ifndef HEADER_PROJECT_H_
#define HEADER_PROJECT_H_

#include "F28x_Project.h"
#include "F2837xS_device.h"
#include "epwm.h"
#include "adc.h"
#include "dac.h"
#include "gpio.h"
#include "timer.h"
#include "variable.h"

#endif /* HEADER_PROJECT_H_ */

