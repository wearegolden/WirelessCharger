/*
 * adc.h
 *
 *  Created on: 2019. 4. 16.
 *      Author: PEETS
 */

#ifndef HEADER_ADC_H_
#define HEADER_ADC_H_

#include "Project.h"

extern void ConfigureADC(void);

#endif /* HEADER_ADC_H_ */
