/*
 * gpio.h
 *
 *  Created on: 2019. 4. 16.
 *      Author: PEETS
 */

#ifndef HEADER_GPIO_H_
#define HEADER_GPIO_H_

#include "Project.h"

extern void ConfigureLED(void);

#endif /* HEADER_GPIO_H_ */
