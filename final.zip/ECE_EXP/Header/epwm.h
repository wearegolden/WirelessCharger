/*
 * epwm.h
 *
 *  Created on: 2019. 4. 16.
 *      Author: PEETS
 */

#ifndef HEADER_EPWM_H_
#define HEADER_EPWM_H_

#include "Project.h"

extern interrupt void epwm1_isr(void);
extern interrupt void epwm2_isr(void);
extern void ConfigureEPWM1(void);
extern void ConfigureEPWM2(void);

#endif /* HEADER_EPWM_H_ */
