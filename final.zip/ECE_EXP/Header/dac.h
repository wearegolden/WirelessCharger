/*
 * dac.h
 *
 *  Created on: 2019. 4. 16.
 *      Author: PEETS
 */

#ifndef HEADER_DAC_H_
#define HEADER_DAC_H_

#include "Project.h"

extern void ConfigureDAC(void);

#endif /* HEADER_DAC_H_ */
